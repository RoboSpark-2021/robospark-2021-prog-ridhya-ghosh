import React from 'react';
import ReactDOM from 'react-dom';

  
// );
class App extends React.Component {
  constructor(props){
    super(props);
    this.state = {isLoginOpen: true};
  }
  showLoginBox(){
    this.setState({isLoginOpen:true})
  }
  render() {
    return (
      <div className="root-container">
        <div className="box-controller">
          <div className="controller" onClick={this.showLoginBox.bind(this)}>
            Login
          </div>
          
        </div>
        <div className="box-container">
          {this.state.isLoginOpen && <LoginBox/>}
        </div>
      </div>
    )
  }
  
}



class LoginBox extends from NewType_1 {
   constructor(props) {
     super(props);
     this.state = {};
   }
   submitLogin() {
     
   }

   render(){
     <div className="inner-container">
       <div className="box">
         <div className="input-group">
           <label htmlFor="username">Username</label>
            <input type="text" name="username" className ="login-input" placeholder="Username"/>
         </div>
        <div className="input-group">
          <label htmlFor="password">Password</label>
          <input type="text" name="password" className="login-input" placeholder="Password"/>
        </div>
        <button type="button" className="login-btn" onClick= {this.submitLogin.bind(this)}>Submit</button>
       </div>
     </div>
   } 
}

ReactDOM.render(
  <App/>, document.getElementById("root"));

// coded by Abhi